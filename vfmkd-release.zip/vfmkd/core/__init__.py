"""
Core training and evaluation modules for VFMKD.
"""

# TODO: Implement core modules
# from .trainer import Trainer
# from .evaluator import Evaluator

__all__ = [
    # "Trainer",
    # "Evaluator",
]