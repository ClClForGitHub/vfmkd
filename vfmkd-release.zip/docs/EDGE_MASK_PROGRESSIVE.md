# 渐进式边缘掩码训练策略

## 🎯 设计思想

在64×64的低分辨率特征图上进行边缘蒸馏时，学生模型的卷积网络会在物体内部产生大量细碎的纹理边缘。这些内部纹理会干扰边缘损失的计算，导致模型难以聚焦于真正的物体轮廓。

**渐进式边缘掩码（Progressive Edge Mask）** 策略通过两阶段训练解决这个问题：

### 📊 两阶段训练流程

```
第1-5个epoch（全局学习阶段）
├─ 关闭边缘掩码
├─ 在整个256×256区域计算BCE+Dice损失
└─ 目标：让模型先学会"在哪里有边缘"（粗定位）

第6-N个epoch（精确对齐阶段）
├─ 启用边缘掩码（3×3核膨胀，±1像素容错区）
├─ 只在膨胀后的边缘区域内计算损失
└─ 目标：让模型专注于"边缘的精确位置"（细对齐）
     同时忽略物体内部的细碎纹理
```

## 🔬 技术实现

### 1. 边缘膨胀（Edge Dilation）

使用 **MaxPool2d** 实现高效的边缘膨胀（等价于形态学膨胀）：

```python
# 3×3核，stride=1，padding=1
# 对二值图（0/1）进行最大池化 = 膨胀操作
dilater = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
edge_mask = dilater(teacher_target)  # 边缘向外扩展1个像素
```

**为什么选择3×3核（±1像素）？**

- ✅ **容忍对齐误差**：在64×64分辨率下，±1像素的偏移是正常的
- ✅ **精确忽略内部**：远离轮廓的内部纹理仍被掩码排除（值为0）
- ✅ **紧凑高效**：不会像5×5或7×7那样过度膨胀

### 2. 掩码BCE损失

```python
# 原始BCE损失（逐像素）
bce_loss_per_pixel = BCEWithLogitsLoss(reduction='none')(pred, target)  # [B, H, W]

# 应用边缘掩码
bce_loss_masked = bce_loss_per_pixel * edge_mask  # 只保留边缘区域的损失

# 归一化（除以有效像素数）
num_valid = edge_mask.sum(dim=(1,2)).clamp(min=1.0)
bce_loss = (bce_loss_masked.sum(dim=(1,2)) / num_valid).mean()
```

### 3. 掩码Dice损失

```python
# 在掩码区域内计算Dice系数
pred_masked = sigmoid(pred) * edge_mask
target_masked = target * edge_mask

intersection = (pred_masked * target_masked).sum()
union = pred_masked.sum() + target_masked.sum()

dice = (2 * intersection + smooth) / (union + smooth)
dice_loss = 1 - dice
```

## 📋 使用方法

### 命令行参数

```bash
python tools/train_distill_single_test.py \
  --features-dir VFMKD/outputs/features_sam2_300 \
  --images-dir VFMKD/datasets/sa1b_subset_300 \
  --loss-type fgd \
  --backbone repvit \
  --epochs 20 \
  --batch-size 4 \
  --lr 1e-3 \
  --enable-edge-mask-progressive \       # 启用渐进式边缘掩码
  --edge-mask-start-epoch 5 \            # 从第5个epoch开始
  --edge-mask-kernel-size 3              # 3×3核（膨胀1像素）
```

### 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--enable-edge-mask-progressive` | False | 启用渐进式边缘掩码 |
| `--edge-mask-start-epoch` | 5 | 从第几个epoch开始启用掩码 |
| `--edge-mask-kernel-size` | 3 | 膨胀核大小（3=±1像素，5=±2像素） |

## 📊 训练日志示例

```
Epoch 1-4: Train total=0.4523 feat=0.3812 edge=0.0711
[全局学习阶段，无边缘掩码]

============================================================
🎯 [Epoch 5] 启用边缘区域掩码！
   从现在开始，损失只在膨胀后的边缘区域（3x3核，±1像素）内计算
   这将忽略物体内部的细碎纹理，专注于精确边缘对齐
============================================================

Epoch 5: Train total=0.3891 feat=0.3205 edge=0.0686
📊 Edge Mask Coverage: 12.34% (avg across 67 batches)
   (边缘掩码覆盖了 12.34% 的像素区域)

Epoch 6-20: ...
[精确对齐阶段，只在边缘区域计算损失]
```

## 🔍 预期效果

### 训练前5个epoch

- **学生模型行为**：在整个图像上产生边缘预测
- **损失计算范围**：全局256×256区域
- **学习目标**：粗略定位物体边缘的大致位置

### 训练第6个epoch开始

- **学生模型行为**：专注于GT边缘附近的精确预测
- **损失计算范围**：仅膨胀后的边缘区域（~10-15%像素）
- **学习目标**：精确对齐边缘位置，忽略内部纹理干扰

### 最终结果

- ✅ **边缘精度提升**：学生预测更接近GT轮廓
- ✅ **内部纹理抑制**：减少物体内部的虚假边缘
- ✅ **收敛速度加快**：模型不再被内部纹理误导

## 🛠️ 调试技巧

### 1. 可视化边缘掩码

在训练脚本中添加可视化代码：

```python
import matplotlib.pyplot as plt

# 在train_epoch中
if batch_idx == 0 and epoch == edge_mask_start_epoch:
    # 可视化第一个batch的边缘掩码
    edge_mask_vis = edge_mask[0].cpu().numpy()  # [H, W]
    plt.imshow(edge_mask_vis, cmap='gray')
    plt.title(f"Edge Mask (Epoch {epoch})")
    plt.savefig(f"outputs/edge_mask_epoch{epoch}.png")
    plt.close()
```

### 2. 监控掩码覆盖率

训练日志会自动打印：

```
📊 Edge Mask Coverage: 12.34%
```

- 如果 < 5%：掩码太小，考虑增大kernel_size（如5）
- 如果 > 30%：掩码太大，考虑减小kernel_size（保持3）
- 理想范围：10-20%（取决于物体大小和复杂度）

### 3. 对比实验

建议进行三组对比实验：

```bash
# A组：无边缘掩码（基线）
python tools/train_distill_single_test.py ... 

# B组：渐进式边缘掩码（推荐）
python tools/train_distill_single_test.py ... --enable-edge-mask-progressive

# C组：从头启用边缘掩码
python tools/train_distill_single_test.py ... \
  --enable-edge-mask-progressive \
  --edge-mask-start-epoch 1  # 从第1个epoch就启用
```

预期结果：**B组 > A组 > C组**

## 💡 最佳实践

1. **epoch划分**：
   - 小数据集（<500张）：前3个epoch全局，之后掩码
   - 中数据集（500-5K张）：前5个epoch全局，之后掩码 ✅ **推荐**
   - 大数据集（>5K张）：前10个epoch全局，之后掩码

2. **kernel_size选择**：
   - 64×64分辨率：kernel_size=3 ✅ **推荐**
   - 128×128分辨率：kernel_size=5
   - 256×256分辨率：kernel_size=7

3. **与其他技术结合**：
   - ✅ 可以与FGD/FSDlike损失结合
   - ✅ 可以与边缘增强（edge_boost）同时启用
   - ✅ 可以与特征蒸馏损失并行使用

## 🔗 相关文件

- 损失函数实现：`vfmkd/distillation/losses/edge_loss.py`
- 训练脚本：`tools/train_distill_single_test.py`
- 可视化工具：`tools/run_vis_only.py`

## 📚 参考

- **形态学膨胀**：用于扩展边缘区域，提供对齐容错
- **Focal Loss思想**：关注难样本（边缘），忽略简单样本（内部）
- **渐进式训练**：先粗后细，逐步聚焦关键区域

---

**Version**: 1.0  
**Date**: 2025-11-01  
**Author**: VFMKD Team

